package types

// Version represents the current version of the x402 package
const Version = "0.1.0"
