console.log(`\x1b[33m⚠️  NOTICE:\x1b[0m
By taking steps to use the search functionality within the x402 Bazaar, you agree to the CDP TOS and that the x402 Bazaar is provided AS-IS.
CDP TOS: (https://www.coinbase.com/legal/developer-platform/terms-of-service)
The endpoints have not been reviewed by Coinbase, so please ensure that you trust them prior to sending funds.`);
