#!/bin/bash
pnpm dev 