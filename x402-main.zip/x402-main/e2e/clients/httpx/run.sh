#!/bin/bash
uv run python main.py 